/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    user_low_power_config.h
  * @author  MCD Application Team
  * @brief   Header for user_low_power_config.c
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef USER_LOW_POWER_CONFIG_H
#define USER_LOW_POWER_CONFIG_H

#endif /* USER_LOW_POWER_CONFIG_H */
